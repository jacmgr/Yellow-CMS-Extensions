<?php
/*
 * Plugin class :: Jac Page Source :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 ) (no changes!!)
 * Povide the markdown source of the current page IN the current page. 
 * Useful for developer/author debugging, and for copy and paste to other pages..
 */
/* SHORTCUT NOT WORKING..... ONLY use from layouts.
 See Readme file.
 See my default layout......
 Learned some from pagesource extension from
	https://github.com/schulle4u/yellow-extensions-schulle4u
TO DO:
	1. SHORTCUT to return html output for any source. (better pre wrapper??)
	So really this is just a generalpurpose pre/pre wrapper with custom page displays.
	Could have more general wrapper, but markdown is sufficient, don;t complicate it.....
=================================================
*/
class YellowJacPageSource {
    const VERSION = "0.8.10";
    public $yellow;         // access to API

	// ------------------------------------------------------    
    // Handle initialisation
    public function onLoad($yellow) {
        $this->yellow = $yellow;
    }
   // Return GET request argument
    public function getGetRequest($key) {
        return isset($_GET[$key]) ? $_GET[$key] : "";
    }
    // See if our request.
    public function checkRequest() {
        return (isset($_GET['source']) && $_GET['source'] == 'true') ? true : false;
    }
	// ???? calling directly from layout avoids recursive calling....
    public function getJacpagesource($page) { 
			$location = $page->getLocation($absoluteLocation = false); //false gives partial
			$fileName = $this->yellow->lookup->findFileFromContentLocation($location, $directory = false);
//			$output = $this->yellow->toolbox->readFile($fileName, 4096);
			$output = $this->yellow->toolbox->readFile($fileName);
            $output = htmlentities($output, ENT_QUOTES);
            // Could put template in external File.
            $output = '<div class="pagesource">
            <h6>Page Location: '.$location.'</h6>
            <h6>Page FileName: '.$fileName.'</h6>
            <a href="#bottomSource" id="topSource" class="btn" >Jump to Formatted Article</a>
            <a href="?source=false" class="btn" >Close Page Source View</a>
            <pre>'.$output.'</pre>
            <a href="#topSource" id="bottomSource" class="btn" >Jump to Top Page Source</a>
            <a href="?source=false" class="btn" >Close Page Source View</a>
            </div>';
            return ($output);  
    }   
    // SEEMS LIKE THIS IS BEING CALLED UNNECESARILY...  I should manually call this in the one above
    // PLACE THE CSS FOR THIS 
    // Handle page extra data
    public function onParsePageExtra($page, $name) {
        $output = null;
         if ($name == "header") {
//            $extensionLocation = $this->yellow->system->get("coreServerBase").$this->yellow->system->get("coreExtensionLocation");
	        $assetLocation = $this->yellow->system->get("coreServerBase").$this->yellow->system->get("coreAssetLocation");
            //jacmgr modify ext location
//            $extensionLocation = $extensionLocation.'/jac/jacpagesource/'; 
			$assetLocation = $assetLocation . 'jac/jacpagesource/'; 
            // CSS filename w/o extension
            $style = "jacpagesource";
            $output .= "<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"{$assetLocation}{$style}.css\" />\n";
 			// NO JS for this...
            // $output .= "<script type=\"text/javascript\" src=\"{$extensionLocation}countdown.js\"></script>\n";
        }
         return $output;
    }
}