<?php
// jacmgr : Site Configuration Extension
// Site Info / Content Location.......  FIX THE CAPITALIZATION INCONSISTENCIES!! 

class YellowJacSitecfg {
    const VERSION = "0.9.3";
    public $yellow;             // access to API

	//  WHY NOT onSTART. If could do an onstart could combine system and site.
	//  However, I do like keeping system and site cfg seperate.
    // Handle initialisation
    public function onLoad($yellow) {
		$this->yellow = $yellow;
		// the cfg file lives in the root folder for this one.  Maybe should live here.......??
		include './'.'jacsite-cfg.php';
		if (!isset($jacSitename)) {$jacSitename = 'Give Your Site a name in jacsite-cfg.php';}
		if (!isset($jacSiteTheme)) {$jacSiteTheme = 'default';}
		if (!isset($jacSubNavigation)) {$jacSubNavigation = array('Paginate', '|', 'Source', 'Help', 'Signin'); }

		$jacConfig = array(
			'Sitename' => $jacSitename,
			'Sitebyline' => $jacSitebyline,
			'Author' => $jacAuthor,
			'Sitecode' => $JACsiteCode,
			'Theme' => $jacSiteTheme,
			'NavigationPages'=> $jacNavigation,
			'SubNavigationPages'=> $jacSubNavigation,
			'coreContentDirectory' => $JACcontentFolder,
	        );	 	

		foreach ($jacConfig as $setting => $value){
			$this->yellow->system->setDefault($setting, $value);
			$this->yellow->system->set($setting, $value);
		}
	}
}