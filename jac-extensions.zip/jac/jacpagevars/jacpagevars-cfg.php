<?php
/*
*   jac PageVars

    'currenttime2' Trying to insert a standard use of datefmt with a pagevar :: Works in MD page.  Silly, Don't use....
     but somehow the substitution is not parseing correctly

*/
$this->config = array(
	'BYOB' => " ** Bring Your Own Bottle ** ",
	'DailyMessage' => 'Daily Message is directing you to Call some function that returns text; Or, Call Your Mom.',
	'currenttimestamp' => time(),
	'currentdate' => date("Y-m-d", time()),
	'currenttime2' =>'[datetimefmt "[%currentdate%]" "l d F Y" ]',
	'wikipedia' => 'https://en.wikipedia.org/',
	'yellocms' => 'https://datenstrom.se/',
	'externalediturl' => $this->yellow->system->get("coreServerBase").'/'.$this->yellow->lookup->findMediaDirectory("coreMediaLocation").'/gallerycontent-admin.php?',
);
