<?php
// jac Page Variables AKA Content Variables that can be used in MARKDOWN
// Yellow Requires extension in one single extension folder. 
// That makes confusing directory structure for me!
// This method lets me use folder organization.
// Install extension in a subfolder with it's necessary files.
require_once 'jac/jacpagevars/jacpagevars-ext.php';