<?php
/*
 * Plugin class :: Jac Page Source :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 ) (no changes!!)
 * Proof-of-Concept.. Quirkey..
 * Description : Meta Data used as page Variables...
	Normal Yellow Meta are available in layouts in Yellow system, but sometimes need them in the Markdown file.
	I needed them in shared pages used as sidebars in a parent page.
	I nned them in markdown page as INPUT into other extension tags.
	Uses syntax [%VARNAME%] syntax in MD File.
	Can use in layout as $page->metaData[$key]
	Note: these are all also available in other extensions and layouts......
	uses onParseContentRaw so these vars van be Inputs into other shortcuts or extensions in a MD PAge.
 */
/*
TO DO:
0. If file does not exist, exit gracefully doing nothin. 
		Warning: String offset cast occurred in C:\WEB\xamp8125\htdocs\yellow\devdocs\system\extensions\jac\jacpagevars\jacpagevars-ext.php on line 155
2. PENDING Figure out why CORE needed modifications to execute event onParseContentRaw
1. DONE (jaccuts extension)  [daterender [%published] fmt="YYYYMMDD"]
3. If you want to add modifiers, then better to do it in layout instead of here; although,
4. Since doing this in raw content; It does it everywhere and does not respect code blocks, so hard in readme file examples!!

====================================================
SAMPLE USE IN MARKDOWN FILE.
---
title: Caligraphy 2013
author: john
Published: 2013-09-23 21:00:00
ImageGallery: galleries/caligraphy/
ImageBanner: galleries/caligraphy/P9280023.JPG
Layout: blog
Tag: family
---
[image [%ImageBanner%] "Nice Caligraphy" left 100 100]

[%author%] published **[%title%]** for your pleasure on [%modified%].
[--more--]
Let me tell you about my caligraphy class.........

## View the Gallery
[gallery [%ImageGallery%].*JPG name zoom 200]

[You can edit this page here]([%editPageUrl%])

END OF MARKDOWN FILE.
=================================================
Typical Data keys in Yellow Meta include everything you put in the meta plus some
(
(array) $page->metaData
    [title] => Home
    [language] => en
    [modified] => 2024-03-29 22:12:34
    [sitename] => UriChip
    [author] => John
    [layout] => default
    [theme] => jaccopenhagen
    [parser] => markdown
    [status] => public
    [titleNavigation] => Home
    [published] => 2024-03-12
    [titleContent] => Home
    [titleHeader] => UriChip
    [editPageUrl] => http://localhost/yellow/yellow-jhinline/edit/
)
All of these values are available on a page as [%key%]

in addition jacpagevars adds the folowing additional hardcoded keys
	[baseurl] => /yellow/devdocs/edit      ???if on an edit page,  "edit" is problamatic in some ways.
	[pagelocation] => /devdocs/system/system-info
	[pagefilename] => content/devdocs/30-system/system-info.md
	[parenttop] => devdocs
	[home] => /
	[externalediturl] => /yellow/devdocs/gallerycontent-admin.php?content/devdocs/30-system#system-info.md
	[notice] => Setting jacvars

FINAL META ARRAY
Array
(
    [0] => YellowArray Object
        (
            [storage:ArrayObject:private] => Array
                (
                    [title] => Daily Summary
                    [language] => en
                    [modified] => 2024-04-03 22:30:46
                    [sitename] => DevDocs
                    [author] => jacmgr
                    [layout] => default
                    [theme] => jaccopenhagen-devdocs
                    [parser] => markdown
                    [status] => public
                    [titleNavigation] => Activity
                    [project] => Yellow CMS - UriChip Blog
                    [purpose] => Entry Page for Daily Summaries
                    [published] => 2024-03-23
                    [layoutNew] => daily
                    [titleContent] => Daily Summary
                    [titleHeader] => Daily Summary - DevDocs
                    [editPageUrl] => http://localhost/yellow/devdocs/edit/devdocs/daily/   
                    [baseurl] => /yellow/devdocs
                    [pagelocation] => /devdocs/daily/
                    [pagefilename] => content/devdocs/20-daily/page.md
                    [parenttop] => devdocs
                    [home] => /
                    [externalediturl] => /yellow/devdocs/gallerycontent-admin.php?content/devdocs/20-daily#page.md
                    [notice] => Setting jacvars
                )

        )

)

FINALLY,  ANYTHING YOU PUT IN the config file will also be made available in the same manner....

     [currenttimestamp] => 1712251580
     [currentdate] => 2024-04-04
     [currenttime2] => [datetimefmt "[%currentdate%]" "l d F Y" ] 
*/
class YellowJacPageVars {
    const VERSION = "0.8.10";
    public $yellow;         // access to API
    public $jacPageVars;
	// ------------------------------------------------------    
    // Handle initialisation
    public function onLoad($yellow) {
        $this->yellow = $yellow;
		include 'jacpagevars-cfg.php';
		//$this->printnice($this->config);
    }
	// onParseContentHtml  -- NOT USED see notes
    // onParseContentHtml occurs AFTER SHORTCUTS PROCESSED and AFTER HTML GENERATED
    // So Doesn't really work if these pagevars are to be INPUTS to other Shortcuts etc.....
    // Those shortcuts would be already processed with the template vars NAMES instead of their values.
	// This would work if the pagevar is NOT used as input to another shortcut, but mine generally are!!
    // SO using onParseContentRaw
	// ------------------------------------------------------    
	//  onParseContentRaw
	//  YELLOW CORE DOES NOT SEEM TO CHECK EXTENSIONS FOR THIS EVENT. So I modified CORE to make sure fires  
    public function onParseContentRaw($page, $text) {   
		// Added Meta data vars......
		// ---------------------------------------------
		$pagelocation = $this->yellow->page->getLocation();
		$pagefilename = $this->yellow->lookup->findFileFromContentLocation($pagelocation, $directory = false);
		$parentTop = $this->yellow->page->getParentTop(); //page object
		// for toplevel file parenttop could be null
		if($parentTop){
			$parentToplocation = $parentTop->getLocation(); 
			if ($parentToplocation != '/') $parentToplocation = trim($parentToplocation,'/');			
		}
		else {
			$parentToplocation = "/";
		}
        // My External Editor
		// jacmgr using an EXTERNAL EDITOR SOMETIMES, instead of internal yellow edit
		// so why not provide my edit url same as yellow provides theirs
		//      gallerycontent-admin.php?content/..fullfolder../lastfolder # filename   so change last slash to pound
		$fileNametemp = $pagefilename; 
		$fileNametemp[strrpos($fileNametemp, "/")] = "#";
		// $externalediturl = $this->yellow->system->get("coreServerBase").'/'.$this->yellow->lookup->findMediaDirectory("coreMediaLocation").'/gallerycontent-admin.php?'. $fileNametemp;
		$externalediturl = $this->config['externalediturl'] . $fileNametemp;
		///  Get the web host url_stat
		// localhost/urichip.com, jhinline.com....
		list($scheme, $address, $base, $location, $fileName) = $this->yellow->lookup->getRequestInformation();
		$URLparent = $scheme.'://'.$address.dirname($base);
		$URLhost = $scheme.'://'.$address;

		// initialize the array
		$this->jacPageVars = array(
					 'baseurl' => $this->yellow->page->getBase(false),
			         'pagelocation' => $pagelocation,
			         'pagefilename' => $pagefilename,
					 'parenttop' => $parentToplocation,
					 'home' => '/',
					 'externalediturl' => $externalediturl,
					 'URLparent' => $URLparent,
					 'URLhost' => $URLhost,
					);
		// additional desired variables....
        $this->jacPageVars['notice'] = "Setting jacPagevars";
		// etc.....
		// ASSEMBLE IT ALL.....
		// Add configs first - 
		foreach( $this->config as $key => $value ){
			$this->jacPageVars[$key] = $value;
		}
		// ----------------------------------------------------------------------
		// add these above variables to the page meta data (just virtual, not written or saved to the md file...))
   		foreach( $this->jacPageVars as $key => $value ) {		
			$page->metaData[$key] = $value;
		}			
		// debug 
		//$this->printnice( array ($page->metaData) , "jacPageVars - Final Set to Meta");
		// ----------------------------------------------------------------------
		// NOW DO IT!!  Replace all occurrences IN THE CURRENT PAGE of a pagevar with data from meta
		// Note: these are all also available in other extensions and layouts......
 		// ----------------------------------------------------------------------
    	foreach( $page->metaData as $key => $value ){
			// Yellow seems to make all Meta START with lowercase regardless of how is entered on page.
			// However: It DOES PRESERVE interior upper/lower case !!!	
			// I am using case independent str_ireplace now....
			// $content = str_replace("[%".$key."%]", $value, $content);
			$text = str_ireplace("[%".$key."%]", $value, $text);
		} 
        // -------------------------------------------------------------------------
        //return the jacvars substituted page raw text
        return $text;  	
    }   
	// ==========================================================================
	public function printnice(array $VAL, $note = "debug output"){
	  echo '<pre>';
	  echo $note."\n";
	  print_r($VAL)	;
	  echo '</pre>';
	}
	// =============================================================================
}
