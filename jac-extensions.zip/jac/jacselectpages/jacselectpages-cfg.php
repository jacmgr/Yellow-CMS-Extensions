<?php
/*
*   jac select Pages Configuration
	Default Values
*/
$this->config = array(
	'selectStartLocation' => "auto",
	'selectShortcutEntries' => "12",
	'selectPaginationLimit' => "12",
	'selecttagStartLocation' => "auto",
	'selecttagShortcutEntries' => "12",
	'selecttagPaginationLimit' => "12",
);
$this->configArguments = array (
            'start' => "auto",
            'entries' => 12,
            'template' => 'TitleListLinks',
            'filter' => null,
            'keyword' => null, 'keywordvalue' => null,
            'exclude' => null,
            'include' => null,
            'orderby'=> null, 'order' => 'desc',
            'paginate' => false, 
            'count' => 12,
            'skip' => 0,
            'excerpts' => 'off',
			);