<?php
/*
 * Plugin class :: Jac Select Pages :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 )
 * 20240506 : jacmgr : rewrote filterpages to selectpages
 * Shortcut for markdown page that sets filters for pagelist (collection) to be displayed on the page
 *			using a pre-made variety of templates.
 * Shortcut for creating Tag Clouds and incorporatin tag request into selectyion parameters.
 * 
 */
/* 
*** Very much based on the BLOG EXTENSIONM, but I made it worse probably!
There are 2 shortcodes here,,,,,
- [ selectpages ...arguments...] Returns a collection of Pages and their final output based on select parameters.
- [ selecttags ...arguments....] Returns a Tag Cloud suitable for sidebars with links.

TO DO:

1. Add DEBUG TAGS   [%jacfilterpages%]  Could probably be a shortcut too...
2. Use INCLUDE and EXCLUDE TAGS
   Fix recursive on TOP....
3. Should be able to do combination: of additional keyword, as visible/invisible, etc.....
3. Most of this needs error checking for missing files, NULL Sets, etc...

====================================================
SAMPLE USE IN MARKDOWN FILE.
---
title: Caligraphy 2013
author: john
Published: 2013-09-23 21:00:00
ImageGallery: galleries/caligraphy/
ImageBanner: galleries/caligraphy/P9280023.JPG
Layout: default
Tag: family
---

Let me tell you about my caligraphy classes. The following articles may be useful.........

[filterpages start=auto 
required='date'   * not implemented yet  Implemented as Keyword=date Keywordvalue=any
exclude=index 
orderby='date' order=desc  
template=false 
excerpts=on 
paginate=true count=10 skip=0]

#Tag Cloud
[filtertags start=top entries=12 template=TagList paginate=true count=5]

END OF MARKDOWN FILE.
=================================================
*/
class YellowJacSelectPages {
    const VERSION = "0.8.10";
    public $yellow;         // access to API
	public $configArguments;
	
	// ------------------------------------------------------    
    // Handle initialisation; set default values to the yellow system ini defaults
    public function onLoad($yellow) {
        $this->yellow = $yellow;
		// sets up $this->configArguments.
		include 'jacselectpages-cfg.php';
    }
	// ------------------------------------------------------    
	//  onParseContentElement - Determine if any shortcuts Content Elements here and execute them
 	public function onParseContentElement($page, $name, $text, $attributes, $type) {
        $output = null; //$output will be the returned page contents...
        if (substru($name, 0, 6)=="select" && ($type=="block" || $type=="inline")) {
           switch($name) {
                case "selectpages": $output = $this->buildSelectedpages($page, $name, $text); break;
     			case "selecttags" : $output = $this->buildTaglist($page, $name, $text);  break;
            }
        }
        return $output;
    } 
	// ------------------------------------------------------  
	// output for the selected page results.
	public function buildSelectedpages($page, $name, $text){
		$output = null;  //null;
		// get attributes included in the actual shortcut $text
		$passedArgs = $this->shortcut_parse_atts($text);	
		//merge actual user entered atts with the defaults.
//$this->printnice($passedArgs, 'before merge');
		$textArgs = $this->shortcut_merge_atts($this->configArguments, $passedArgs);
//$this->printnice($textArgs, 'after merge');
		$startLocation = $textArgs['start']; // also could be $textArgs['folder'];
		if ($startLocation == '/') $startLocation = 'top';  //wierd issue for shared page
		$shortcutEntries = $textArgs['entries']; //used for pagination or to just return first n items.
		$shortcutTemplateName = 'layout-'.$textArgs['template'].'.html';
		// get all pages at and under page filterstart  why passing (top, auto, foldername)
        $pages = $this->getAllPagesfromstart($page, $startLocation);
//$this->printnice($textArgs, 'line 91');
		if (($textArgs['keyword'] != null) && ($textArgs['keywordvalue'] != null) && ($textArgs['keywordvalue'] != 'any')){

			$exactMatch = false; //false//true
			$pages->filter($textArgs['keyword'], $textArgs['keywordvalue'], $exactMatch);	//, "true", $exactMatch);
//echo '<br> line 95 ..selecting keyword... count : '. $textArgs['keyword'].' :: '.$textArgs['keywordvalue'].' :: '.count($pages);
		}
		// This will just get pages that have the keyword, regardless of what its value is.
		if (($textArgs['keyword'] != null) && ($textArgs['keywordvalue'] == 'any')){
		    $newpages = new YellowPageCollection($this->yellow);
	        foreach ($pages as $page) {
	            if ($page->isExisting($textArgs['keyword'])) {			
						//keep page
			            $newpages->append($page);
				}
			}
			//assign the pages with only the keyword to pages
			$pages = $newpages;
//echo '<br> line 109 ..selecting keyword... count : '. $textArgs['keyword'].' :: '.$textArgs['keywordvalue'].' :: '.count($pages);
		}	        
//echo '<br> line 111 after keyword check';
		// Tag Cloud $_GET Request
		// Of these posts, what are request tagged
		if ($page->isRequest("tag")) {
		 $keyword = 'tag';
		 $keywordvalue = $page->getRequest("tag");
		 $pages->filter($keyword, $keywordvalue, false);
		}
		// ==============================================
		//paqginate and ordering.......
		$orderAscending = true; 
		if ($textArgs['order'] == 'descend') $orderAscending = false;		
		$pages->sort($textArgs['orderby'], $orderAscending); 
		if($textArgs['paginate'] == 'true') $pages->paginate($textArgs['count']) ; // YellowPageCollection
		if($textArgs['paginate'] == 'false') $pages->limit($textArgs['count']) ; // YellowPageCollection		
		// ===========================================================================
		// THE LAYOUT.............
		// Using my own include file with screeen buffering to capture html
		// .....Can't figure out yellow templates with alternate locations and themes and sending variables.
		$output = '';
		// could use native yellow.......
		ob_start();
			include $shortcutTemplateName;  // developes variable "output" and $paginateDisplay
			$output .= ob_get_contents(); 
		ob_end_clean();
		// return the assembled HTML to yellow
		return $output;	        
	}
	// ---------------------------------------------------------
	//mostly bastardized from blog plugin.....
    public function buildTaglist($page, $name, $text) {
        $output = null;  // output will be returned by shortcut
		// get attributes included in the actual shortcut $text
		$passedArgs = $this->shortcut_parse_atts($text);	
		//merge actual user entered atts with the defaults.
		$textArgs = $this->shortcut_merge_atts($this->configArguments, $passedArgs);
		$startLocation = $textArgs['start']; // also could be $textArgs['folder'];
		if ($startLocation == '/') $startLocation = 'top';  //wierd issue for shared page
		$shortcutEntries = $textArgs['entries']; //used for pagination or to just return first n items.
		$shortcutTemplateName = 'layout-'.$textArgs['template'].'.html';
    	//start page for the selection to begin (i.e. convert, top, auto, folder)
    	$filterStart = $this->getSelectstartpage ($page, $startLocation);
		// get all pages at and under page filterstart 
        $pages = $this->getAllPagesfromstart($page, $startLocation);
		//get tags from these pages
        $tags = $pages->group("tag", false, "count");
        if ($shortcutEntries!=0) $tags = array_slice($tags, 0, $shortcutEntries, true);
        uksort($tags, "strnatcasecmp");
		ob_start();
			include $shortcutTemplateName;  // developes variable "output" and $paginateDisplay
			$output = ob_get_contents(); 
		ob_end_clean();        
		// return the assembled HTML to yellow
        return $output;
    }
	// ------------------------------------------------------  
	// return overall Page Collection based on start location
	// recursive used....
    public function getAllPagesfromstart($page, $filterStartLocation = 'top') {
       if ($filterStartLocation =="auto") {
            $pages = $page->getChildrenRecursive();
        } else if($filterStartLocation=="top") {
            $pages = $this->yellow->content->index();
        } else { 
			$folder = "/$filterStartLocation/";
			$filterStart = $this->yellow->content->find($folder);
            $pages = $filterStart->getChildrenRecursive();
 		}
        return $pages;    	
    }
	// --------------------------------
	// tag functin needs the actual page object f the start location.
    public function getSelectstartpage ($page, $filterStartLocation = 'top') {
       if ($filterStartLocation =="auto") {
            // for current page folder
            $filterstart = $page;
        } else if($filterStartLocation=="top") {
            $filterStartLocation = "/";  
            $filterStart = $this->yellow->content->find($filterStartLocation);
            $pages = $this->yellow->content->index();
        } else { 
			$folder = "/$filterStartLocation/";
			$filterStart = $this->yellow->content->find($folder);
 		}
        return $filterStart;    	
    }
	// ==========================================================================	
	// Utility Functions.  Mat be replaced by yellow Native stuff......
	// ==========================================================================	
	/**
	 * Retrieve all attributes from the shortcuts tag.
	 *
	 * The attributes list has the attribute name as the key and the value of the
	 * attribute as the value in the key/value pair. This allows for easier
	 * retrieval of the attributes, since all attributes have to be known.
	 *
	 * @since 2.5
	 *
	 * @param string $text
	 * @return array List of attributes and their value.
	 */
	public function shortcut_parse_atts($text) {
		$atts = array();
		$pattern = '/(\w+)\s*=\s*"([^"]*)"(?:\s|$)|(\w+)\s*=\s*\'([^\']*)\'(?:\s|$)|(\w+)\s*=\s*([^\s\'"]+)(?:\s|$)|"([^"]*)"(?:\s|$)|(\S+)(?:\s|$)/';
		$text = preg_replace("/[\x{00a0}\x{200b}]+/u", " ", $text);
		if ( preg_match_all($pattern, $text, $match, PREG_SET_ORDER) ) {
			foreach ($match as $m) {
				if (!empty($m[1]))
	                            if(strtolower($m[1]) == 'file'){ $atts[strtolower($m[1])] = $m[2]; }else{
	                            $atts[strtolower($m[1])] = stripcslashes($m[2]);}
				elseif (!empty($m[3]))
					$atts[strtolower($m[3])] = stripcslashes($m[4]);
				elseif (!empty($m[5]))
					$atts[strtolower($m[5])] = stripcslashes($m[6]);
				elseif (isset($m[7]) and strlen($m[7]))
					$atts[] = stripcslashes($m[7]);
				elseif (isset($m[8]))
					$atts[] = stripcslashes($m[8]);
			}
		} else {
			$atts = ltrim($text);
		}
		return $atts;
	}
	/**
	 * Combine user attributes with known attributes and fill in defaults when needed.
	 *
	 * The pairs should be considered to be all of the attributes which are
	 * supported by the caller and given as a list. The returned attributes will
	 * only contain the attributes in the $pairs list.
	 *
	 * If the $atts list has unsupported attributes, then they will be ignored and
	 * removed from the final returned list.
	 *
	 * @since 2.5
	 *
	 * @param array $pairs Entire list of supported attributes and their defaults.
	 * @param array $atts User defined attributes in shortcut tag.
	 * @return array Combined and filtered attribute list.
	 */
	public function shortcut_merge_atts($pairs, $atts) {
		$atts = (array)$atts;
		$out = array();
		foreach($pairs as $name => $default) {
			if ( array_key_exists($name, $atts) )
				$out[$name] = $atts[$name];
			else
				$out[$name] = $default;
		}
		return $out;
	}
	// ==========================================================================
	public function printnice(array $VAL, $note = "debug output"){
	  echo '<pre>';
	  echo $note."\n";
	  print_r($VAL)	;
	  echo '</pre>';
	}
	// =============================================================================
}
