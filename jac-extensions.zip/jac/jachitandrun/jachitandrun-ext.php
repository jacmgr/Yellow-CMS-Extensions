<?php
/**
 * Plugin class :: Jac Hit and Run :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 )
*/
class YellowJacHitandRun {
    const VERSION = "0.8.15";
    public $yellow;         // access to API
	public $config;    // jacmgr local configuration array
	
    public function onLoad($yellow) {
        $this->yellow = $yellow;
		// extension configuration if any. sets up $this->config
		include 'jachitandrun-cfg.php';
    }
	// --------------------------------------------------------
	// Places form at the shortcut taglocation...
    public function insertForm() {
		$layoutname = $this->config['jachitandrunLayout-'.$this->config['jachitandrunLayout-useform']];
		$output = '';
		// could use native yellow.......
		ob_start();
			include $layoutname;  // developes variable "output" and $paginateDisplay
			$output = ob_get_contents(); 
		ob_end_clean();
		// return the assembled HTML to yellow
		return $output;	
}
	// checks if user logged in. Based on yellow edit Users....
	// ------------------------------------------------------
    public function loggedIn() {
		$loggedin = false;
		if ($this->yellow->user->isUser("name")) $loggedin = true; 
		return $loggedin;
    }
	// --------------------------------------------------------
    // See if our request. Can be Used by layout...
    public function checkRequest() {
        return (isset($_GET['hitandrun']) && $_GET['hitandrun'] == 'true') ? true : false;
    }
// --------------------------------------------------------------------
//  onParseContentElement
 	public function onParseContentElement($page, $name, $text, $attributes, $type) {
        $output = null;
         // ---------------------------
        // check for next [jachitandrun]
        if ($name =="jachitandrun" && ($type=="block" || $type=="inline")) {
			if($this->loggedIn()){
				// sets a flag that is used in layout to draw the form.
				$_GET['hitandrun'] = 'true';  //used by layout......
				//  need something to substitute the tag, could be null, but lets say 
				$output = '> Hit and Run in Use... ';
				// load form.  must have the div with markdown=1  or will not show form.....
				$output .= '<div markdown="1">' . $this->insertForm($this->yellow->page) . '</div>';
				//see if any arguments :: NONE IN USE YET, But can set date formats in config....
				// list($dateARG, $fmtARG, $relative, $reldays) = $this->yellow->toolbox->getTextArguments($text);            
				//if post is set then this is response to form. make sure not a cancel
				if(isset($_POST['Submit-btn'])){
					$newcontent = $_POST['textarea'];
					// method updates raw content and redirects to reload this page...
					$this->addHitandRun($page, $newcontent);
					//never actually executed, becuase never gets here due to redirect in method above!
					unset ($_POST);
				}
			}
			else{
				// not logged in, so just remove the tag from output.
				// $output = '';
				// debug check....
				 $output = '! You must log in to use Hit and Run...';	
			}
	        return $output;
        }        
        // jachit and run not used, return null
        return $output;
    }
// --------------------------------------------------------
// adds hitandrun content to original raw content and saves the file.
// redirects and reloads the file.
	public function addHitandRun($page, $newcontent){
		$output = null;
		// really just want top of file - replace the [jachitandrun]  with '[jachitandrun]+/n+newcontent'
		$ToReplace = '[jachitandrun]'; // repolace what string currently in file....
		$Replacemant = '[jachitandrun]'."\n\n";
		$Replacemant .= "### ".date($this->config['jachitandrunDateformat'])."\n";
		$Replacemant .= $newcontent;
		// get the raw content file...					
		$filecontents = $this->yellow->toolbox->readFile($page->fileName);
		//substitute
		$newfilecontents = str_replace ( $ToReplace, $Replacemant, $filecontents );
		$this->yellow->toolbox->writeFile($page->fileName, $newfilecontents);  
		$url=strtok($_SERVER["REQUEST_URI"],'?');
		header('Location: '.$url);
		die();	
	}
}
