<?php
/*
*		jacHitandRun Extension CFG file.
*
*/
date_default_timezone_set('America/New_York');
$this->config = array(
//    'jachitandrunDateformat' => "F j, Y g:i a (l)",
    'jachitandrunDateformat' => "g:i a (l) F j, Y ",
    'jachitandrunLayout-inline' => 'layout-jachitandrun-form-inline.htm',
    'jachitandrunLayout-dialog' => 'layout-jachitandrun-form-dialog.htm',    
	'jachitandrunLayout-useform' => 'inline',
);
