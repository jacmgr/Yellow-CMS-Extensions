<?php
// jac MathJax
// Yellow Requires extension in one single extension folder. 
// That makes confusing directory structure for me!
// This method lets me use folder organization.
// Install extension in a subfolder with it's necessary files.
require_once 'jac/jacmathjax/jacmathjax-ext.php';