<?php
/*
*   MathJax Config......
*   Just getting it from CDN.
*   You Could download it here and use it to.
*   What the heck.... put both in the congig.
*   Some CDN didn;t work with my prepared pages that used mathjax....
*   Im not gonna figure out why or if i need to change my mathjax formats.....
*   Worked:  Y-mathjax   Y -asciimath  https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML
*     note I saved this source for my "local copy" of the script without modification. But really the script still goes to CDN,
*     However, you could make configuration options in the local copy (I did not). 
*   Partial: Y-mathjax   N-asciimath   https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js
*   Partial: Y-mathjax   N-asciimath   https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js
*
*	Documentation for Configuring:  [ I did not need to configure anything ] Your mileage may vsary.
*	https://docs.mathjax.org/en/latest/web/configuration.html#configuring-mathjax 
*	https://docs.mathjax.org/en/latest/options/index.html#configuring-mathjax
*
*   For Fun and Learning, you can cut and paste examples from here.......
*   https://docs.mathjax.org/en/latest/web/examples.html#web-examples
*
*   DO NOT CHANGE "%mathjax_script%". That is keyword in extension code.
*/
$this->config = array(
	'using_script' => 'LOCAL',
	'usingExtraHTML' => true,
    'CDN' => 'https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML',
    'LOCAL' => 'MathJax.js?config=TeX-MML-AM_CHTML',
	'template' => '<script type="text/javascript" src="%mathjax_script%"></script>',
);
