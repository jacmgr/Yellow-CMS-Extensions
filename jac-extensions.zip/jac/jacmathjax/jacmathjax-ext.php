<?php
/*
 * Plugin class :: Jac MathJax :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 ) (no changes!!)
 * Description: Simply makes/uses a system setting that is then available in your Layout.
 */
/**
 *  Simply makes a system setting that is then available in your Layout.
  	If the meta field 'mathjax' exists and is true  $this->yellow->system->setDefault("use_mathjax_script"
 	That's it now check in your layout and include what you need there.....
	NOTE:
	Don't really need this plugin if that's all it does.  From the layout you can already
	access the meta fields directly..... and add whatever you need....
	So Why?  Placeholder for future development.  Learninig to make extensions.

	TODO:
	DONE: In extensions add an extrahtml to add the script automatically instead of doing in layout..
		  Now do not need to put anything in LAYOUT. ExtraHTML adds script.

 */
/*
    GOOD FOR TEX: http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS_HTML-full
    GOOD ASIMATH: src="http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=AM_HTMLorMML-full
    Good for all markups: http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_HTMLorMML.js
 *
 * Deals with the double backtick as the text marker for mathjax.
 * - deals with `` and converts it tosingle ` for final page
 * - deals with escaped '\``' so can use it in documentation pages
 * - if the marker (``) is found in the page then loads the mthjax javascript in the page
 * - i.e. don't load it if there is no mathjax in page.
=================================================
---
Title: Using Mathjax 
Published: 2013-06-26 21:00:00
mathjax: true
ImageBanner: eq0048LP.jpg
Layout: blog
Tag: readme
---
[mathjax]: http://www.mathjax.org
[mathjaxscript]: https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML
[ascimath]: http://www1.chapman.edu/~jipsen/mathml/asciimath.html

[image [%ImageBanner%] "MathJax" left 100 100]

[MathJax][mathjax] is a javascript system for rendereing math equations in Tex, Lex, MML, and AsciiMath.  All it takes is inclusion of the MathJax javascript in your displayed page.  A plugin is not needed, but it does make it easier for non programmers.

### Here is an example using TEX formats

~~~~
<p>
When ``$a \ne 0$`` , there are two solutions to ``\(ax^2 + bx + c = 0\)`` and they are
``$$x = {-b \pm \sqrt{b^2-4ac} \over 2a}.$$``
</p>
~~~~

<p>
When `$a \ne 0$`, there are two solutions to `\(ax^2 + bx + c = 0\)` and they are
`$$x = {-b \pm \sqrt{b^2-4ac} \over 2a}.$$`
</p>

END OF MARKDOWN FILE.
=================================================
*/
class YellowJacMathJax {
    const VERSION = "0.8.10";
    public $yellow;         // access to API
    // public $config= array();
			/* include config during onLoad = array(
			'using_script' => 'mathjax_local',
			'usingExtraHTML' => true,
		    'mathjax_cdn' => 'https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML',
		    'mathjax_local' => 'MathJax.js?config=TeX-MML-AM_CHTML',
			'template' => '<script type="text/javascript" src="%mathjax_script%"></script>',
			);
			*/
    public function onLoad($yellow) {
        $this->yellow = $yellow;
		// Custom configs for this extension. Sets Defaults
		// I don't write defaults to yellow-system or yellow-languager, 
		// but you could.....
		include 'jacmathjax-cfg.php';
		// $this->printnice($this->config);
    }
 	
    public function onParseContentRaw($page, $text) {   
		// just sets a system.ini value to flag that this page has mathjax.
	    $this->yellow->system->setDefault("use_mathjax_script", false);
	    $this->yellow->system->setDefault("mathjax_script", false);
	    $this->config["mathjax_script"] = false;
	    if((isset($page->metaData['mathjax'])) && ($page->metaData['mathjax'] == 'true')){

		    $scriptname = $this->config['using_script'];
		    $scripturl = $this->config[$scriptname]; // = $this->config[$this->config['using_script']];
			if( $scriptname == 'LOCAL'){
				$extensionLocation = $this->yellow->system->get("coreServerBase").$this->yellow->system->get("coreExtensionLocation");         	
	            $extensionLocation = $extensionLocation.'jac/jacmathjax/lib/';				
		    	$scripturl = $extensionLocation.$scripturl; 
			}
		    $this->yellow->system->setDefault("use_mathjax_script", true);
	        $this->yellow->system->setDefault("mathjax_script", $scripturl);
			$this->config["mathjax_script"] = $scripturl;
		    // vars available in Layout
			// from layout: $this->yellow->system->get("use_mathjax_script"); 
	        // from layout  $this->yellow->system->get("mathjax_script");  
	    } 
    }
    public function onParsePageExtra($page, $name) {
        $output = null;
//		if(!$this->config['usingExtraHTML'] return null;
        if ($name == "header") {
		    $scripturl = $this->config['mathjax_script'];
            $scripttemplate = $this->config['template'];
		    $output .= str_replace("%mathjax_script%", $scripturl, $scripttemplate);
        }
         return $output;
    }
	// ==========================================================================
	public function printnice(array $VAL, $note = "debug output"){
	  echo '<pre>';
	  echo $note."\n";
	  print_r($VAL)	;
	  echo '</pre>';
	}
	// =============================================================================
}