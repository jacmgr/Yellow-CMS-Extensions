<?php
/*
*		jacCuts Extension CFG file.
*
*/
date_default_timezone_set('America/New_York');
$this->config = array(
	'jaccutsdefaultdate' => date("l, F jS, Y g:i a"),
	'jaccutsdefaultdatefmt' => "m-d-Y",
	'jaccutsdefaulttimezone' => "EST",
	'jaccutsdefaultdaterelative' => false,
    'jaccutsdefaultdaterelativedays' => 365,
);
