<?php
/**
 * Plugin class :: Jac Cuts :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 )
 * A collection of miscellaneous minor shortcuts
 *		datetimefmt - takes a date and a format and spits it back to you.  
 					  Used in page, but could be called from layout.
		See README FILE for many examples.
		
TODO
	1. How to use other languages, should be able to set a default in config, or inside the extension read a system var for language.
	 	Then, Use the Yellow functions for date time ?????
	 	
[datetimefmt 07/04/2023]

[datetimefmt 07/04/2023 "Y-m-d"]

[datetimefmt 07/04/2023 "l d F Y" ]

[datetimefmt 07/04/2023 "l d F Y" relative 365]
 =================================================
*/
/*

  /// Just background researc saved here
    public function onParseContentRaw($page, $text) {   

date(format,timestamp)
< ?php $DateFormatted = date("Y M d", strtotime($this->yellow->page->getHtml("published"))); ? >
< ?php echo $this->yellow->page->getDateHtml("published") ? >
page-> getDateStandard($text, $language = ""): string
    }
}
*/
/*
YELLOW HAS SO MANY OPTIONS FOR DATE AND DATEFORMATTING.......
NOte , this is NOT likely to be used on a "key" value.  Just on dates I might write in my content.
i.e. on 7/4/1776, I was not yet born....
on [dateformat 7/4/1776], I was not yet born....

Or, in a new-page-blog.md shared template. I want to stick in the first heading automatically on file creation.
# [datetimefmt @datetime "XXXXX"]

====
(from API "language section")
page->getDateStandard($text, $language = ""): string
Return text as language specific date, convert to one of the standard formats

page->getDateRelative($timestamp, $format, $daysLimit, $language = ""): string
Return Unix time as date, relative to today

page->getDateFormatted($timestamp, $format, $language = ""): string
Return Unix time as date

(from api Page section)
page->getDate($key, $format = ""): string
Return page setting as language specific date

page->getDateHtml($key, $format = ""): string
Return page setting as language specific date, HTML encoded

page->getDateRelative($key, $format = "", $daysLimit = 30): string
Return page setting as language specific date, relative to today

page->getDateRelativeHtml($key, $format = "", $daysLimit = 30): string
Return page setting as language specific date, relative to today, HTML encoded

page->getDateFormatted($key, $format): string
Return page setting as date

page->getDateFormattedHtml($key, $format): string
Return page setting as date, HTML encoded
====
CoreDateFormatShort: F Y
CoreDateFormatMedium: Y-m-d
CoreDateFormatLong: Y-m-d H:i
CoreDatePast: today, yesterday, @x days ago, 1 month ago, @x months ago, 1 year ago, @x years ago, on @x
CoreDateFuture: soon, tomorrow, in @x days, in 1 month, in @x months, in 1 year, in @x years, on @x
CoreDateMonthsNominative: January, February, March, April, May, June, July, August, September, October, November, December
CoreDateMonthsGenitive: January, February, March, April, May, June, July, August, September, October, November, December
CoreDateWeekdays: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
*/
/*
d - The day of the month (from 01 to 31)
D - A textual representation of a day (three letters)
j - The day of the month without leading zeros (1 to 31)
l (lowercase 'L') - A full textual representation of a day
N - The ISO-8601 numeric representation of a day (1 for Monday, 7 for Sunday)
S - The English ordinal suffix for the day of the month (2 characters st, nd, rd or th. Works well with j)
w - A numeric representation of the day (0 for Sunday, 6 for Saturday)
z - The day of the year (from 0 through 365)
W - The ISO-8601 week number of year (weeks starting on Monday)
F - A full textual representation of a month (January through December)
m - A numeric representation of a month (from 01 to 12)
M - A short textual representation of a month (three letters)
n - A numeric representation of a month, without leading zeros (1 to 12)
t - The number of days in the given month
L - Whether it's a leap year (1 if it is a leap year, 0 otherwise)
o - The ISO-8601 year number
Y - A four digit representation of a year
y - A two digit representation of a year

a - Lowercase am or pm
A - Uppercase AM or PM
B - Swatch Internet time (000 to 999)
g - 12-hour format of an hour (1 to 12)
G - 24-hour format of an hour (0 to 23)
h - 12-hour format of an hour (01 to 12)
H - 24-hour format of an hour (00 to 23)
i - Minutes with leading zeros (00 to 59)
s - Seconds, with leading zeros (00 to 59)
u - Microseconds (added in PHP 5.2.2)
e - The timezone identifier (Examples: UTC, GMT, Atlantic/Azores)
I (capital i) - Whether the date is in daylights savings time (1 if Daylight Savings Time, 0 otherwise)
O - Difference to Greenwich time (GMT) in hours (Example: +0100)
P - Difference to Greenwich time (GMT) in hours:minutes (added in PHP 5.1.3)
T - Timezone abbreviations (Examples: EST, MDT)
Z - Timezone offset in seconds. The offset for timezones west of UTC is negative (-43200 to 50400)
c - The ISO-8601 date (e.g. 2013-05-05T16:34:42+00:00)
r - The RFC 2822 formatted date (e.g. Fri, 12 Apr 2013 12:01:05 +0200)
U - The seconds since the Unix Epoch (January 1 1970 00:00:00 GMT)


https://code.tutsplus.com/working-with-date-and-time-in-php--cms-31768t
// Output � 2018 
echo date('Y');
// Output � September 2018 
echo date('F Y');
// Output � 13 September, 2018 
echo date('d F, Y');
// Output � 13 September, 2018 (Thursday) 
echo date('d F, Y (l)');
// Output � 11:03:37 AM 
echo date('h:i:s A');
// Output � Thursday, 11:04:09 AM 
echo date('l, h:i:s A');
// Output � 13 September 2018, 11:05:00 AM 
echo date('d F Y, h:i:s A');

'm/d/Y'
'F j, Y'
'F Y'
'd F, Y'
'd F, Y (l)'
'h:i:s A'
l, F j, Y
l, F jS, Y
F j, Y g:i a
'h:i:s A'
'l, h:i:s A'
'd F Y, h:i:s A'
M j, Y @ G:i
g:i A
g:i:s a

F j, Y g:i a � November 6, 2010 12:50 am
F j, Y � November 6, 2010
F, Y � November, 2010
g:i a � 12:50 am
g:i:s a � 12:50:48 am
l, F jS, Y � Saturday, November 6th, 2010
M j, Y @ G:i � Nov 6, 2010 @ 0:50
Y/m/d \a\t g:i A � 2010/11/06 at 12:50 AM
Y/m/d \a\t g:ia � 2010/11/06 at 12:50am
Y/m/d g:i:s A � 2010/11/06 12:50:48 AM
Y/m/d � 2010/11/06

*/

class YellowJacCuts {
    const VERSION = "0.8.15";
    public $yellow;         // access to API

    public function onLoad($yellow) {
        $this->yellow = $yellow;
		// extension configuration if any
		include 'jaccuts-cfg.php';
    }
// -----------------------------------------------------------------------------------------
// datetimefmt
//  useful for layouts
//  echo $this->yellow->extension->get("jaccuts")->getdatetimefmt('2024-03-12', "Y-m", 200);
//  echo $this->yellow->extension->get("jaccuts")->getdatetimefmt('2024-03-12', "l r f d", 200);
    public function getdatetimefmt($dateARG, $fmtARG="Y-m-d", $relative="", $reldays = "") {
		$output = null;
		if (is_string_empty($dateARG)){
			$output = $this->config['jaccutsdefaultdate'];
			return $output;
		} 
		else if ($dateARG == 'now'){
				$datearg = date("l, F jS, Y g:i a");						
		}
		if (is_string_empty($fmtARG)) $fmtARG = $this->config['jaccutsdefaultdatefmt']; 
		if (is_string_empty($reldays)) $reldays = $this->config['jaccutsdefaultdatefmt'];   
		if (is_string_empty($relative)) {
					$relative = $this->config['jaccutsdefaultdaterelative']; //false;
		 			$reldays = false;
		}    	
		       if(!$relative) {
		       	  // Note sure if this is internationalized for language.
		       	  $output = date($fmtARG, strtotime($dateARG)); 
		       }else{
		          $output = $this->yellow->language->getDateRelative(strtotime($dateARG), $fmtARG, $daysLimit = $reldays, $language = "");
				}
		return $output;
   	}
	// useful for in page shortcut tags.
	// note that page is actually irrelevent and not used in this shortcut........
	// 0.0.9 onParseContentElement replaces onParseContentShortcut
	//  public function onParseContentElement($page, $name, $text, $attributes, $type) {
	// Now there's a new argument $attributes. You can set class/id attributes on certain content elements. 
	// The event handler gets passed down theses attributes and you can handle them in your own code. 
	// This can be useful for code elements and notice elements.
 	public function onParseContentElement($page, $name, $text, $attributes, $type) {
    	// public function onParseContentShortcut($page, $name, $text, $type) {
//echo "parseing again.......";
        $output = null;
        if (substru($name, 0, 8)=="datetime" && ($type=="block" || $type=="inline")) {
			list($dateARG, $fmtARG, $relative, $reldays) = $this->yellow->toolbox->getTextArguments($text);            
            $output = $this->getdatetimefmt($dateARG, $fmtARG, $relative, $reldays);
        	return $output;
        }
        // ---------------------------
        // check for next jaccut......
        $output = null;
        if ($name =="XXXXXXXXXXXXjachitandrun" && ($type=="block" || $type=="inline")) {
			list($dateARG, $fmtARG, $relative, $reldays) = $this->yellow->toolbox->getTextArguments($text);            
            $newcontent = "> You've been Hit and Runned!!";
            $output = $this->addHitandRun($page, $newcontent);
/*
default without button.... Everytime page is loaded update with current time !!!
i.e. copt that message above  and update page.....

*/


	        return $output;
        }        
        
        return $output;
    }
// -----------------------------------------------------------------------------------------
// next shortcut........ became its own shortcut.....
// ----------------------------------------------------- imgconfirmed
//	public function XXXXXXXXXXXXXXXXXXXXXXXXaddHitandRun($page, $newcontent){

}
