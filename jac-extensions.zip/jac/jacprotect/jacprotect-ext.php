<?php
// jac Protect Auth extension
// pretty basic and not gonna protect against real threats who want to do harm
// but keeps lookie loos away.....
// Has unrelated reset page for public ibrowser test......
class YellowJacProtect {
    const VERSION = "0.9.3";
    public $yellow;             // access to API
	public $config;

    // Handle initialisation
    public function onLoad($yellow) {
		$this->yellow = $yellow;
		//extension config  
		include 'jacprotect-cfg.php';  //$this->config
		foreach ($this->config as $setting => $value){
			$this->yellow->system->setDefault($setting, $value);
			$this->yellow->system->set($setting, $value);
		}
		$this->config['isLoggedIn'] = false;
// ==== un-comment this to generate password hashes when you want to change passwords.
// ====  copy paste your hashed vals to your configs; then recomment this section.......
//	$hashpassword = $this->yellow->toolbox->createHash('your desired password', 'bcrypt', $cost = 10) ;
//	echo $hashpassword; 
//	exit;
	}
	// =====================================================================
    //  Used from Layout to get to password entry form...
    public function insertFormfromlayout($page, $name = null, $text = null) {
		$label_expiration_minutes = $this->yellow->system->get('jacprotectPasswordDuratiion') / 60;
		$form = '<form action="" method="post">
				<div class="form">
					<label for="pesto">PASSWORD (expires in '.$label_expiration_minutes.' minutes):</label>
					<br /><input type="text" size="40" class="form-control" name="pesto" id="pesto" value="" />
					<input type="hidden" name="jacStatus" value="jacsubmitted" />
					<input type="submit" value="jacLogin" class="btn" />
				</div>
				</form>';
		return $form;
    }
	// =====================================================================
	// check if request sent and if so, process to set login cookie......
	// i lika pesto for a pestoward
	// Additionally and sort of unrelated, if request to reset a page, processed here
	// currently only used for the ibrowse demo site....
    public function onParseContentRaw($page, $text) {   
		// can be changed
		$this->setSystemCommentPassword();
		$output = null;
		// password submitted check
		if ($page->isRequest("jacStatus")) {
			$pesto = filter_var(trim($this->yellow->page->getRequest("pesto")), FILTER_UNSAFE_RAW, FILTER_FLAG_STRIP_LOW);
			if (!is_string_empty($pesto) && ($this->yellow->toolbox->verifyHash($pesto, 'bcrypt', $this->yellow->system->get('jacprotectPasswordMain')))) {
				//we have good login
			    $output = '! GOOD PASSWORD YOU ARE LOGGED IN   ';
				//set a cookie to last for X minutes
				$dur = $this->yellow->system->get('jacprotectPasswordDuratiion');
				setcookie('jacdaywithtime', 'testuser', time() + $dur);
				$url=strtok($_SERVER["REQUEST_URI"],'?');
				header('Location: '.$url);
				die();	
			}
			else {
				$output = '! BAD PASSWORD   '; 	
			}
		} 
		// Reset Page Request....
		if ($page->isRequest("jacReset")) {
			$this->resetPage($this->yellow->page);
		}
        return $output.$text; 
	}
	// =====================================================================
	// checks if user logged in. Based on cookies I set in password processing
	// can be called from layout.
    public function isLoggedIn() {
		// print_r($_COOKIE);	
		$loggedin = false;
		if (isset($_COOKIE["jacdaywithtime"])) {
			$loggedin = true;
		}
		return $loggedin;
    }
	// =====================================================================
	//coment can have only one passwrd reference in extension. jacPestoAward.....
	// hard coded here for 2 different sites and their password..in the config
    public function setSystemCommentPassword() {
    	if( $this->yellow->system->get("Sitecode") == 'pcfam'){
    		$pw = $this->config['jacPestoAward'];
			$this->yellow->system->set('jacPestoAward', $pw);    		
    	}else {
			$pw = $this->config['jacprotectPasswordComments'];
			$this->yellow->system->set('jacPestoAward', $pw);
    	}
      	return;
    }
	// =====================================================================
	// testing potential feature...
	// Allows a page to be rest to its original content that is stored in a pagefolder/resetpages folder
	// hard coded to allow this single page to be reset.....'content/9-about/imagebrowser.md'  
    public function resetPage($page) {
		$allowresetpage = 'content/9-about/imagebrowser.md';
		if ($page->fileName == $allowresetpage){
			//open reset page
			$resetpage = dirname($page->fileName).'/resetpages/'.basename($page->fileName);
			$originaltext = $this->yellow->toolbox->readFile($resetpage);
			$this->yellow->toolbox->writeFile($page->fileName, $originaltext);
			//header reload page  problems refreshing browser, so try this querystring method.
			$url=strtok($_SERVER["REQUEST_URI"],'?');
			$rnd=time();
			header('Location: '.$url.'?'.$rnd);
			die();				
		}
		return null;
    }
}
