<?php
/*
*   jac select Pages Configuration
	Default Values
	Duration is in seconds. 1 min = 60 sec ; 1 hr = 3,600 ; 0.5 hr = 1800
	Comment password has no duration. Good for one form post
	PestoAward is for comments on a different site, otherwise jacprotectPasswordComments is default.
*/
//days and thoughts
$this->config = array(
	'jacprotectPasswordMain' => '$2y$10$OW9C73rnzJGqcE5yIC/4HOo3OU4J0GhAlQ/HRUlwy1G.vxMXrC1NO',
	'jacprotectPasswordDuratiion' => 10*60,
	'jacprotectPasswordComments' => '$2y$10$QqQ1wa3EXZSNQhA3GnJRd.JPKgpH19TWGBAJdufqFhks8vqz2Vpfq',
	'jacPestoAward' => '$2y$10$fg/vwk3qAqqd/pZhaInm6OIC8/U9INPMn8HBgyL0G/OdyGfY6KYem',

);
//		$this->yellow->system->set("jacPestoAward", $jacPestoAward);
// see extension jacsitecfg-ext.php to configure new passwords.
