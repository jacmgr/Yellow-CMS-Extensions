<?php
// CONFIG FOR :: Jac Image Select :: Version 0.0.9
/* 
Notes:
	usecreatelink and require login are future development.
	problematic not sure of login methodologies.
	leaving it open is simple and should be fine since editorws would be acting quickly....

	if someone does not want the link and login, they can simply assign the image as
  	              [image system/image-coming-soon-placeholder-300x300.png] in the first place, No extension needed.

    'jacImagelist-usecreatelink' => true,    NOT IMPLEMENTED
    'jacImagelist-requirelogin' => true,     NOT IMPLEMENTED
    'jacImagelist-replacementimage" =>       USE ANYFILE YOU WANT,  
    'jacImagelist-extensions' =>             No REGEX implemented, be explicit ::  SHOULD HAVE AN MP4 THUMB
    'jacImagelist-startLocation' => 		 TODO:   Sould use system vars coreMediaLocation basis 
    'jacImagelist-inline' => 'layout-jacimagelist-inline.htm',  NOT WORKING
    'jacImagelist-dialog' => 'layout-jacimagelist-dialog.htm',  NOT WORKING  
    'jacImagelist-one' => 'layout-jacimagelist-one.htm',        GOOD - USE IT
	'jacImagelist-useform' => 'one',   
*/
$this->config = array(
    'jacImagelist-usecreatelink' => true,
    'jacImagelist-requirelogin' => true,
    'jacImagelist-replacementimage' => 'system/image-coming-soon-placeholder-300x300.png',  
    'jacImagelist-extensions' => 'jpg,jpeg,JPEG,JPG,png,PNG,gif,GIF,ico,ICO,svg,SVG,mp4,MP4',
    'jacImagelist-startLocation' => '/media/images/',
    'jacImagelist-inline' => 'layout-jacimagelist-inline.htm',
    'jacImagelist-dialog' => 'layout-jacimagelist-dialog.htm',    
    'jacImagelist-one' => 'layout-jacimagelist-one.htm',   
	'jacImagelist-useform' => 'one',
);
