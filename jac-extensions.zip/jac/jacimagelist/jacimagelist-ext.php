<?php
/**
 * Extension class :: Jac Image Select :: Version 0.0.9
 * 20240413 : jacmgr : Updated for Datenstrom Yellow 0.9  ( discussion #967 )
 * 20240515 : jacmgr : additional coordination with image extension....
 
Notes:
	usecreatelink and require login are future development.
	problematic not sure of login methodologies.
	leaving it open is simple and should be fine since editorws would be acting quickly....

	if someone does not want the link and login, they can simply assign the image as
  	              [image system/image-coming-soon-placeholder-300x300.png] in the first place, No extension needed.

Layouts:
   only -one is actually functioning......
   
*/
/*
This little feature should be designed to only functions if you are LOGGED IN from yellow edit.... BUT IT IS NOT YET!!!
This little browser selector works strictly off of $GET requests triggered by clicking on a trigger image in the md content.
In the yellow image (or jacimage) extension will place the "noimage image" and selector link trigger.
The yellow image extension checks if image exists and if not, sets the trigger link.
The trigger links starts the $_GET requests that end up here in IMAGELIST extension. 
This extension then permanently replaces the trigger link with the selected image.
If no image selected the noimage image and trigger link remains

------------------------------------------------------------------------------------------
TODO:   The trigger link is only active if you are logged in thru yellow edit. 
TODO:   Option to use the trigger, or just keep the no image without link.
------------------------------------------------------------------------------------------

ToDo:
1. Figure out why thumbnail generation not working.
2.  Minimize image changes, so it depends on imagelist for 
    providing the noimage and trigger through a imagelist method.......
 i.e image still checks for this extension, and if exists call this extension to 
         place the no image image and trigger links.....
3. Add config value to "do nothing", "add noimage image", "add nomage image and trigger link

Operation:
The requests are in sequence......
		// ?imgbrowse&img=some-missing-imagename  //trigger link on a missing image 
		// ?imgbrowse&img=some-missing-imagename&imgselect=foldername  //select folder from browser
		// ?imgbrowse&img=some-missing-imagename&imgselected=filename  //select image from browser
		// ?imgbrowse&img=some-missing-imagename&imgconfirm=filename   //confirm selection

No sessions or cookies or javascript used, so continue passing the GET on each url (imgbrowse, img)

Note, part of why I tried this way is because my image folders are very very large, so trying
	not to load them all at once.  Also, this is not general public facing, only me, the creator 
	of the pages uses it.  Public just sees an image coming soon image.
*/
class YellowJacImageList {
    const VERSION = "0.8.17";
    public $yellow;    		//access to API
	public $config;    		// jacmgr local configuration array
    // Handle initialisation
    public function onLoad($yellow) {
        $this->yellow = $yellow;
		// Maybe use later for JS and CSS; jachac added checkif usePageExtra and if use jacimagelist
		$this->usePageExtra = false;
		// extension configuration if any
		// sets up jacmgr $this->config
		// there is no reason to store this in yellow.....
		include 'jacimagelist-cfg.php';
		$this->config['alreadyprinted'] = false;
        
        $this->yellow->system->set("replacementimage", "system/image-coming-soon-placeholder-300x300.png");  
		$this->yellow->system->set("jacimagetriggerquery", "imgbrowse&img=");
	}
	// --------------------------------- process request if $_GET imgbrowse set.....
	// if request, then insert the shortcut [jacimagelist] into the content to be processed by onParseContentElement
	// save the request vars to be used in later links query strings
    public function onParseContentRaw($page, $text) {   
	        if ($page->isRequest("imgbrowse")) {
	        	$browserlocation = "[jacimagelist]\n";	
				// this is wonky....needs refactoring.
				// yellow processecs these even on SHARED PAGES.....
				// So this particular method would put the browser at each location of a shared page (sidebars, widgets, etc.....)
				// This "alreadyprinted" thing stops it from propagating, but needs to be rethunk... 
				if($this->config['alreadyprinted'] == false){
					$text = $browserlocation.$text;
					$this->config['alreadyprinted'] = true;
				}
			}
			// these ifs are seperated; but would always have both of them!
			if ($page->isRequest("img")) {
				$missingimagename = $page->getRequest("img");
				$this->yellow->system->set("jacimagemissingimage", "$missingimagename");
				$this->yellow->system->set("jacimagereplacequery", "imgbrowse&img=$missingimagename");
			} 
        //return the jacvars substituted page raw text with [jacimagelist] slapped on the front end.
        return $text;
    }
	// ---------------------------------- process request if [jacimagelist] present
    public function onParseContentElement($page, $name, $text, $attributes, $type) {    	
        $output = null;
        if ($name=="jacimagelist" && ($type=="block" || $type=="inline")) {
            list($filePath, $fileExtensions) = $this->yellow->toolbox->getTextArguments($text);
        	if ($fileExtensions == "") $fileExtensions = $this->config['jacImagelist-extensions'];
        	$extensions = preg_split("/\s*,\s*/", $fileExtensions, 0, PREG_SPLIT_NO_EMPTY);
        	$filePath = $this->config['jacImagelist-startLocation'].$filePath;
			// -----------------------------------------------
			// if completed and confirmed selection, process raw content update 
			// and then refresh page. So if succeeds, never returns here... 
			if ($page->isRequest("imgconfirmed")) {
				$output = $this->imgconfirmed($page, $filePath, $fileExtensions);
				return $output;
			}			
			// -----------------------------------------------
			// if selected an image, show full information and request confirmation
			if ($page->isRequest("imgselected")) {
				$output = $this->imgselected($page, $filePath, $extensions);
				return $output;
			}
			// -----------------------------------------------
			// If selected a sub folder, show gallery images in that folder, and 
			// the links to any subfolders
			if ($page->isRequest("imgselect")) {
				$output = $this->imgselect($page, $filePath, $extensions);
				return $output;
			}
			// -----------------------------------------------------------------
			// Default operation upon starting or re-starting the chain of requests
			$output = $this->imglist($page, $filePath, $extensions);
	        return $output;
		}  // end if shortcut is jacimglist........
    }
// ----------------------------------------------------- imglist
// Creates the list of images and html
	public function imglist($page, $filePath, $extensions){
		$output = null; 
//		$filePath = '/media/images/galleries/'; but need to trim/add the left slash sometimes if it is home.
//      $fileLocation = galleries/
		$fileLocation = $this->mediaLocationRemove("$filePath");; 
		$filePath = ltrim($filePath, '/');
		$arrayofFiles = array();
        if ($this->yellow->lookup->isValidFile($filePath) && is_dir($filePath)) {
			$arrayofFiles = $this->getDirectoryFileArray($filePath, $fileLocation, $extensions);
			// -------------------------------------    $templatedata array for layout
			$output .= $this->insertForm($this->yellow->page, 
						array('arrayofFiles'=>$arrayofFiles, 'filePath'=>$filePath, 'fileLocation'=>$fileLocation));
		} else {
	       	// NOT VALID FILE OR DIR	
 			$output .=" <br> imglist 125ish: You probably have an incorrect imgselect. Typo or Folder does not exist.....$filePath";
       	}
		return $output;
	}
// ----------------------------------------------------- imgselect
// gets the selected folder and does the imglist starting at that folder.
// note the "passed in filepath" is irtrelevent. rplaced with the request 
	public function imgselect($page,  $filePath, $extensions){
	 	$imgselected = 'imgselect';
		$filePath = $page->getRequest($imgselected);
		$filePath = $this->config['jacImagelist-startLocation'].$filePath;
		$output = $this->imglist($page, $filePath, $extensions);
		return $output;
	}
// ----------------------------------------------------- imgselected
// after selection, this is the confirmation form. Maybe should template it future...
	public function imgselected($page, $filePath, $extensions){
		$imageFileName = $page->getRequest("imgselected");
		$output = null;
		$output .= "<b>You selected the image : ".$imageFileName.'</b>'; 
		$output .= '<div class-widewrapper><a href="?'.$this->yellow->system->get("jacimagereplacequery").'&imgconfirmed='.$imageFileName.'" class="btn" >Confirm Image Insertion</a></div>';  
		$size=400;
		$filePath = ltrim($this->config['jacImagelist-startLocation'], '/').$imageFileName;
		$output .= $this->getImageHtml($filePath, $size); //just image tag
		return $output;
	}
	// ----------------------------------------------------- imgconfirmed
	// confirmed, so replace the filename in the existing image tag IN THE RAW CONTENT.
	// yes, no checking, bad security. Requires logged in user to access this feature.
	public function imgconfirmed($page, $filePath, $extensions){
		$output = null;
		$imageFileName = $page->getRequest("imgconfirmed");
		$imageFileName = $this->mediaLocationRemove($imageFileName);
		//did not have session vars, so saved this in ini!!  Sorry.....
		$imageToReplace = $this->yellow->system->get("jacimagemissingimage");
		$imageToReplace = $this->mediaLocationRemove($imageToReplace);
		// get the raw content file...					
		$filecontents = $this->yellow->toolbox->readFile($page->fileName);
		// -replace in [image anotherphoto.jpg alttag left 50%] 
		// -i.e. find "anotherphoto.jpg" and replace with the confirmed image $imageFileName. 
		// -save file.....
		$newfilecontents = str_replace ( $imageToReplace, $imageFileName, $filecontents );
		$this->yellow->toolbox->writeFile($page->fileName, $newfilecontents);  
		// header and refresh to same page with NO requests since finished! 
		// using $rnd parameter to assure better likelihood of browser refresh
		$url=strtok($_SERVER["REQUEST_URI"],'?');
		$rnd=time();
		header('Location: '.$url.'?'.$rnd);
		die();	
	}
	//  =====================   Support Functions ==================
	// -------------------------------------- insert the browser form html ...
	// create the content of the image browser from the layout. Will be inserted in current page.
    public function insertForm($page, $templatedata) {
		// $templatedata is array($arrayfiles, $filepath, other needed variables)
		extract($templatedata);
		//$this->printnice($templatedata);
		$layoutname = $this->config['jacImagelist-'.$this->config['jacImagelist-useform']];
		$output = '';
		ob_start();
			include $layoutname;  // developes variable "output" for browser content
			$output = ob_get_contents(); 
		ob_end_clean();
		return $output;	
}
	// -------------------------------------- adjust yellow paths...
	public function mediaLocationRemove($imagename){
		$prefix = $this->config['jacImagelist-startLocation'];
		if (substr($imagename, 0, strlen($prefix)) == $prefix) {
  			$str = substr($imagename, strlen($prefix));
			//		if($str == "") $str = '/';
		    return $str;
		}else{
			return $imagename;
		}
 	}
	// -------------------------------------- Recursive directory/file
	//  reads specified folder and files; returns array
    private function getDirectoryFileArray($startDirectory, $startLocation, $extensions) {
		// reference https://zaemis.blogspot.com/2012/07/php-recursive-directory-traversal.html  and yellow filelist extension.
		// similar to core.php  line 2077ish  : public function getDirectoryEntriesRecursive($path, $regex = "/.*/", $sort = true, $directories = true, $includePath = true, $levelMax = 0) {
		// this does not have the regex, or option for levels or path inclusion,
        $output = null;
        $directoryHandle = opendir($startDirectory);
        $files = $directories = [];
         while (($entry = readdir($directoryHandle))!==false) {
            if ($entry[0]==".") continue;
            $entryType = $this->yellow->toolbox->getFileType($entry);
            if (is_file($startDirectory.$entry) && (!$extensions || in_array($entryType, $extensions))) {
                $files[] = $entry;
            } elseif (is_dir($startDirectory.$entry) && ($entry[0]!=".")) {
                 $directories[$entry] = $this->getDirectoryFileArray($startDirectory.$entry."/", $startLocation.$entry."/", $extensions, null);
            }
        }
        closedir($directoryHandle);
       	uksort($directories, "strnatcmp");
        natcasesort($files);
		// $this->printnice($directories, 'directories at: '.$startLocation.'->'.$startDirectory);
		return ($directories+$files);
   }
	// --------------------------------------------- thumbnails
	// called from LAYOUT.....
	// GET thumbnailimage  WHY NOT CREATING THUMBNAIL in the imagelist functions. 
	// RETURNS ORIGINAL..... Oh well....no thumb here....refactor later......
	public function getImageThumb($imageFileName, $size, $tagtype = true){
		$imageFileName = $this->config['jacImagelist-startLocation'].$imageFileName;
	    list($src, $width, $height) = $this->yellow->extension->get("image")->getImageInformation($imageFileName, $size, $size);
		// $this->printnice(array('$imageFileName'=>$imageFileName, '$src'=> $src), 'getImageThumb : Thumbname');  
		return $src; 	
	}
	// ------------------------------------------ construct an image link
	// mostly becuase thumbs not working here......
	// refactor this down to not be so tightly integrated.......
	public function getImageHtml($imageFileName, $size){
		$output = null;
	    list($src, $width, $height) = $this->yellow->extension->get("image")->getImageInformation($imageFileName, $size, $size);
	    list($widthInput, $heightInput) = $this->yellow->toolbox->detectImageInformation($imageFileName);
	    if (!$widthInput || !$heightInput) $widthInput = $heightInput = "500";
	    $alt = $imageFileName;
	    $output .= "<img src=\"".htmlspecialchars($src)."\"";
	    if ($width && $height) $output .= " width=\"".htmlspecialchars($width)."\" height=\"".htmlspecialchars($height)."\"";
	    $output .= " alt=\"".htmlspecialchars($alt)."\" title=\"".htmlspecialchars($alt)."\" />";
		return $output;
	}
	// ---------------------------------------from [image] extension called] create trigger
	// called from IMAGE Extension
	public function createTriggerLink($missingimagename, $linktext){
		// link text can be anything that goes in an <a>linktext</a> tag
		// in the case of being called from image extension, it is a fully formed <img> tag
        // $output = '<a href="linktoinputform.php with request trigger" ><img unchanged ></img> </a>';
		$href=$this->yellow->system->get("jacimagetriggerquery").$missingimagename;
	    $triggerlink = '<a href="?'.$href.'" class="noimage">'.$linktext.'</a> \n';
		return $triggerlink;
	}
	// ------------------------------------------ my little debugging function
	public function printnice(array $VAL, $note = "debug output"){
	  echo '<pre>';
	  echo $note."\n";
	  print_r($VAL)	;
	  echo '</pre>';
	}
}
